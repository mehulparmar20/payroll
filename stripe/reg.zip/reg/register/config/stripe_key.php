<?php

$auth = array(
    'secrate_key_live' => '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',
    'secrate_key_test' => 'sk_test_51GzePFHpxXHfgq9UsUYEwyLhplZvLMaaxQyGlih6q4jlsiyCjClkXRepQ3q8oC7wj72xFelXxS04mER1d7o4XWa4008Mr0KZ5O',
    'publishable_key_live' => 'pk_live_51GzePFHpxXHfgq9UsW0zLpHGbLLzUsSaUZH8QCFDBYnmY8yK0JNehLarwK8MePSw6nrjvKrf8eQyC9sRvXFlKByf00ZzyOv74G',
    'publishable_key_test' => 'pk_test_51GzePFHpxXHfgq9Upqmprvo61wT5AqVqoxC7fZ6CNh1Cb9BnFUvPkQA6S99hLHhoOShT9CNUKLIBg6XSpLniNIgL002t2u6s3J',
);